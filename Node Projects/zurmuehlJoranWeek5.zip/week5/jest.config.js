const jestConfig = {
    testMatch: ["**/__tests__/*.mjs?(x)"],
}

module.exports = jestConfig;